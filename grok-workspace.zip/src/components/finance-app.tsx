import { useEffect } from "react";
import { SHELL } from "@/finance/shell";

export function FinanceApp() {
  useEffect(() => {
    const w = window as Window & { __mcfBoot?: boolean; showApp?: () => void };
    if (w.__mcfBoot) {
      w.showApp?.();
      return;
    }
    w.__mcfBoot = true;
    const s = document.createElement("script");
    s.id = "finance-engine";
    s.src = "/finance-engine.js";
    document.body.appendChild(s);
  }, []);

  return <div className="finance-root" dangerouslySetInnerHTML={{ __html: SHELL }} />;
}
