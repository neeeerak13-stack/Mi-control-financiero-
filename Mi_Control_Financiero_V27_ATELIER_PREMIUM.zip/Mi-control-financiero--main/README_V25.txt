MI CONTROL FINANCIERO — V25

ESTADO
Esta entrega contiene la aplicación web/PWA actualizada y sus pruebas automatizadas. La lógica financiera principal se probó en Chromium. El ZIP NO contiene todavía una APK compilada.

QUÉ SE VALIDÓ
- 31 recorridos funcionales de navegador: inicio, navegación, movimientos, cálculo de ingresos/gastos/ahorros, cuentas, presupuestos, análisis, categorías, deudas, metas, recurrentes, perfiles, respaldo/restauración, CSV, copiloto, proyección y persistencia.
- 15 pruebas automatizadas pasan en la auditoría local.
- Migración desde los datos locales del formato V24.
- Dos scripts inline y service worker pasan la verificación de sintaxis.
- No hay IDs HTML duplicados ni manejadores inline sin función asociada.
- Los estilos de Aurora, el botón/markup de Aurora y la barra inferior conservan las huellas SHA-256 del baseline V24.

CAMBIOS DE INTEGRIDAD
- Se mantienen sincronizadas las categorías al renombrarlas o eliminarlas, incluidos los recordatorios recurrentes.
- Se protegen las categorías base y se evita cambiar el tipo de categorías que ya tienen referencias.
- Se limpian vínculos de deuda/meta/recurrente al cambiar el tipo de un movimiento.
- Los cobros del día 31 se habilitan el último día de los meses cortos.
- Se valida el contenido de los respaldos antes de sobrescribir el almacenamiento local.

CÓMO USAR LA VERSIÓN WEB
- Extrae el ZIP y abre index.html para una prueba local en un navegador compatible.
- Para instalarla como PWA y disponer de caché sin conexión, publícala en un hosting HTTPS.
- Los datos siguen siendo locales en el navegador/dispositivo. Exporta el respaldo desde Cuenta antes de cambiar de dispositivo o instalación.

ANDROID
- .github/workflows/build-apk.yml ya instala Java 21, Node 22, Android SDK, ejecuta las pruebas y prepara Capacitor 8.6.0.
- La salida automatizada se llama APK preview debug y usa el identificador com.micontrolfinanciero.preview. Es una instalación de prueba separada; no actualiza ni comparte datos con la app que ya está instalada.
- Para obtener esa APK hay que subir el contenido de este ZIP al repositorio GitHub y ejecutar el workflow Build Android APK. Luego se descarga el artefacto generado por Actions.
- No instalar la APK preview esperando que reemplace la aplicación actual. La actualización sobre la instalación existente requiere verificar el applicationId y la firma original, que no están disponibles para esta auditoría.
