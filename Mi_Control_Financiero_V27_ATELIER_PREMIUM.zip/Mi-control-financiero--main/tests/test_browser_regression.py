import json
import shutil
from pathlib import Path
import pytest
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]

def test_financial_flows_in_real_chromium():
    html = (ROOT / "index.html").read_text(encoding="utf-8")
    marker = "load();showApp();"
    assert html.count(marker) == 1
    html = html.replace(marker, "/* initialization deferred to test harness */", 1)
    script = (ROOT / "tests" / "browser_flows.js").read_text(encoding="utf-8")
    with sync_playwright() as playwright:
        browser_path = shutil.which("chromium") or shutil.which("chromium-browser")
        launch_options = {"headless": True, "args": ["--no-sandbox", "--disable-dev-shm-usage"]}
        if browser_path:
            launch_options["executable_path"] = browser_path
        browser = playwright.chromium.launch(**launch_options)
        page = browser.new_page(viewport={"width": 390, "height": 844}, accept_downloads=True)
        page.route("**/*", lambda route: route.abort())
        page_errors = []
        page.on("pageerror", lambda error: page_errors.append(str(error)))
        page.set_content(html, wait_until="commit", timeout=15000)
        page.evaluate("""() => {
          const values = new Map();
          const storage = {
            get length() { return values.size; },
            key(i) { return [...values.keys()][i] ?? null; },
            getItem(k) { return values.has(String(k)) ? values.get(String(k)) : null; },
            setItem(k,v) { values.set(String(k), String(v)); },
            removeItem(k) { values.delete(String(k)); },
            clear() { values.clear(); }
          };
          Object.defineProperty(window, 'localStorage', {configurable:true, value:storage});
          window.confirm = () => true;
          window.__prompts = [];
          window.prompt = () => window.__prompts.shift() ?? null;
        }""")
        results = page.evaluate("async (source) => await (0, eval)(source)()", script)
        browser.close()
    failed = [item for item in results if not item["ok"]]
    assert not page_errors, "Errores JavaScript en navegador: " + repr(page_errors)
    assert not failed, "Pruebas funcionales fallidas: " + json.dumps(failed, ensure_ascii=False)
    assert len(results) >= 24, "La suite debe cubrir al menos 24 flujos; solo ejecutó %s" % len(results)
    print(f"{len(results)} flujos comprobados en Chromium: " + ", ".join(item["name"] for item in results))


def test_existing_v24_local_data_migrates_into_profile_without_loss():
    html = (ROOT / "index.html").read_text(encoding="utf-8")
    marker = "load();showApp();"
    assert html.count(marker) == 1
    html = html.replace(marker, "/* initialization deferred to migration test */", 1)
    old_state = {
        "transactions": [{"id": 42, "type": "income", "amount": 125000, "category": "Salario", "description": "Ingreso anterior", "date": "2026-11-03", "account": "nequi"}],
        "budgets": {"Alimentación": 50000}, "monthlyBudget": 200000,
        "monthlyIncomeTarget": 300000, "monthlyReports": {},
        "categories": [{"name": "Ahorro", "type": "saving"}, {"name": "Salario", "type": "income"}],
        "accounts": {"cash": 10000, "nequi": 125000, "nu": 0},
        "debts": [], "savingsGoals": [], "recurringExpenses": []
    }
    with sync_playwright() as playwright:
        browser_path = shutil.which("chromium") or shutil.which("chromium-browser")
        launch_options = {"headless": True, "args": ["--no-sandbox", "--disable-dev-shm-usage"]}
        if browser_path:
            launch_options["executable_path"] = browser_path
        browser = playwright.chromium.launch(**launch_options)
        page = browser.new_page()
        page.route("**/*", lambda route: route.abort())
        page.set_content(html, wait_until="commit", timeout=15000)
        page.evaluate("""(oldState) => {
          const values = new Map([
            ['mcf_display_name', 'Perfil anterior'],
            ['mcf_final_v4', JSON.stringify(oldState)]
          ]);
          const storage = {
            get length(){return values.size},
            key(i){return [...values.keys()][i] ?? null},
            getItem(k){return values.has(String(k))?values.get(String(k)):null},
            setItem(k,v){values.set(String(k),String(v))},
            removeItem(k){values.delete(String(k))},
            clear(){values.clear()}
          };
          Object.defineProperty(window,'localStorage',{configurable:true,value:storage});
        }""", old_state)
        page.evaluate("load();showApp();")
        result = page.evaluate("""() => ({
          active:localStorage.getItem(ACTIVE_PROFILE_KEY),
          name:localStorage.getItem(NAME_KEY),
          list:JSON.parse(localStorage.getItem(PROFILES_KEY)||'[]'),
          saved:JSON.parse(localStorage.getItem(KEY)||'{}'),
          available:totalAvailable()
        })""")
        browser.close()
    assert result["active"] and result["name"] == "Perfil anterior"
    assert any(row["id"] == result["active"] for row in result["list"])
    assert result["saved"]["transactions"][0]["id"] == 42
    assert result["saved"]["transactions"][0]["amount"] == 125000
    assert result["saved"]["budgets"]["Alimentación"] == 50000
    assert result["available"] == 260000
