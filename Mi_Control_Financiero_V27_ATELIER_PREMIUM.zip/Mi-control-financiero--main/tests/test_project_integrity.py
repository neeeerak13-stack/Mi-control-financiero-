from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / "index.html").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")

def test_required_android_inputs_exist():
    for name in ("index.html", "manifest.json", "service-worker.js", "icon-192.png", "icon-512.png", "Lumi.glb"):
        assert (ROOT / name).is_file() and (ROOT / name).stat().st_size > 0

def test_financial_accounting_and_profiles():
    assert "if(t.type==='income')income+=+t.amount;else if(t.type==='saving')savings+=+t.amount;else expense+=+t.amount" in HTML
    assert "(t.type==='expense'||t.type==='saving')?-Number(t.amount)" in HTML
    assert "t.type==='expense'&&t.debtId===id" in HTML
    assert "t.type==='saving'&&t.goalId===g.id" in HTML
    assert "KEY='mcf_profile_data_'+active" in HTML
    assert "'mcf_profile_data_'+id" in HTML

def test_current_month_category_chart():
    analysis = re.search(r"function renderAnalysis\(\)\{(.*?)\nfunction debtPayments", HTML, re.S)
    assert analysis
    assert "t.type==='expense'&&t.category===c.name&&String(t.date).slice(0,7)===monthKey()" in analysis.group(1)

def test_recurring_expenses_need_confirmation():
    recurring = re.search(r"function registerRecurringExpense\(id\)\{(.*?)\nfunction removeRecurringExpense", HTML, re.S)
    assert recurring and "confirm(" in recurring.group(1)
    assert "r.lastRegistered===m" in recurring.group(1)

def test_android_workflow_is_debug_only_and_limited():
    assert 'appId": "com.micontrolfinanciero.preview"' in WORKFLOW
    assert "assembleDebug" in WORKFLOW
    assert "assembleRelease" not in WORKFLOW
    assert ("permissions:" + chr(10) + "  contents: read") in WORKFLOW
    assert "upload-artifact@v4" in WORKFLOW

def test_scripts_are_present_and_service_worker_registered():
    scripts = re.findall(r"<script\b[^>]*>(.*?)</script\s*>", HTML, re.I | re.S)
    assert len(scripts) >= 1 and all(x.strip() for x in scripts)
    assert (ROOT / "service-worker.js").is_file()


def test_full_backup_and_restore_are_available():
    assert "function exportFullBackup()" in HTML
    assert "function importFullBackup(event)" in HTML
    assert "mi-control-financiero-backup" in HTML
    assert "mcf_profile_data_" in HTML
    assert "Respaldo completo preparado" in HTML
    assert "Restaurar este respaldo reemplazará" in HTML


def test_category_rename_and_delete_preserve_recurring_references():
    assert "if(r.category===categoryOriginal)r.category=name" in HTML
    assert "if(r.category===name)r.category=fallback" in HTML
    assert "hasRecurring=(state.recurringExpenses||[]).some(r=>r.category===categoryOriginal)" in HTML


def test_linked_transaction_ids_are_cleared_when_type_changes():
    assert "delete t.debtId" in HTML
    assert "delete t.recurringId" in HTML
    assert "delete t.goalId" in HTML


def test_recurring_due_day_is_clamped_to_month_end():
    assert "dueDay=Math.min(Number(r.day)||1,lastDay)" in HTML


def test_backup_restore_validates_profiles_before_writing():
    restore = re.search(r"function importFullBackup\(event\)\{(.*?)\nfunction exportTransactionsCSV", HTML, re.S)
    assert restore
    body = restore.group(1)
    assert "ACTIVE_PROFILE_KEY" in body and "PROFILES_KEY" in body
    assert "profileIds" in body and "profileIds.includes(v[ACTIVE_PROFILE_KEY])" in body
    assert body.index("JSON.parse") < body.index("confirm(") < body.index("localStorage.setItem")


def test_pwa_manifest_and_safe_service_worker():
    assert '<link rel="manifest" href="./manifest.json">' in HTML
    assert "navigator.serviceWorker.register('./service-worker.js')" in HTML
    sw = (ROOT / "service-worker.js").read_text(encoding="utf-8")
    assert "mcf-shell-v3" in sw and "event.request.method!=='GET'" in sw
    assert "caches.delete(name)" in sw


def test_protected_mascot_and_navigation_styles_unchanged():
    import hashlib
    style = re.search(r"<style>(.*?)</style>", HTML, re.S).group(1)
    nav = re.search(r'<nav class="bottom".*?</nav>', HTML, re.S).group(0)
    aurora = re.search(r'<button[^>]*id="coachOrb".*?</button>', HTML, re.S).group(0)
    assert hashlib.sha256(style.encode()).hexdigest() == "31113bf15599857174ccc5cb4c21a186a479b5434748187dbb44c396b46c9169"
    assert hashlib.sha256(nav.encode()).hexdigest() == "86b1f64f0b1c3518e7e2114f145b57b1b5034eb23cf1bc57368e56aa12431241"
    assert hashlib.sha256(aurora.encode()).hexdigest() == "d459426cd6c137d77a07493799eb0268988e7f24f004b1a4f893d725eadfb916"
